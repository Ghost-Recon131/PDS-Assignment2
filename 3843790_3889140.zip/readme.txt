PDS Assignment 2 by:
Jingxuan Feng s3843790
Ho Yin Lam s3889140

NoteBook file: 
Run like any other Jupyter notebook file. Will also work with Visual Studio Code or PyCharm if the nessasary plugins are installed. 